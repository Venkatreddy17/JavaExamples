public class Detention {
    public static void main(String[] args) {

        // Task 2 – call the function 6 times. 

        printLines();
        printLines();
        printLines();
        printLines();
        printLines();
        printLines();

   }


    //Task 1 - Make a function here. See the doc comment for details. 

    /**
    * Name: printLines - it prints the four lines. 
    */

   public static void printLines() {
    System.out.println("I will not copy and paste code.");
    System.out.println("I will use Camel Case when writing class names.");
    System.out.println("I will use lower Camel Case when writing function names.");
    System.out.println("I will use lower Camel Case when writing variables names.\n");

   }

}