package src.main.model.account;

public abstract class Account {



}
