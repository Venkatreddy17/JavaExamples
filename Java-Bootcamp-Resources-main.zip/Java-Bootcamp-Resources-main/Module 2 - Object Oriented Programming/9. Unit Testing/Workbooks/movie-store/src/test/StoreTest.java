package src.test;

import src.main.models.Store;

public class StoreTest {

    Store store;

}
