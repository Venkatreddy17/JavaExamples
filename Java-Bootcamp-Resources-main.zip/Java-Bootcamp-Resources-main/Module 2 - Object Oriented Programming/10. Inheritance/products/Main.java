public class Main {
  
    static final String FILE_NAME = "products.txt";

    public static void main(String[] args) {

    }
  
    /**
     * Function Name: getData
     * @return Product[]
     * @throws FileNotFoundException
     * 
     * Inside the function:
     *   1. Loads the data from products.txt
     */
}
